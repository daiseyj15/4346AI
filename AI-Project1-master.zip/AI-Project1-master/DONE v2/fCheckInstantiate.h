#ifndef FCHECKINSTANTIATE_H
#define FCHECKINSTANTIATE_H
#include "Engine.h"
#include <iostream>
#include <string>
using namespace std;
class fCheckInstantiate
{
private:

public:
    fCheckInstantiate();
    string setQuestions(string& Major, VariableList a, bool done);
    ~fCheckInstantiate();



};

#endif